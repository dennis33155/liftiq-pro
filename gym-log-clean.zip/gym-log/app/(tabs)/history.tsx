import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useMemo } from "react";
import {
  Alert,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { EmptyState } from "@/components/EmptyState";
import { LiveDateTime } from "@/components/LiveDateTime";
import { useColors } from "@/hooks/useColors";
import { useWorkout } from "@/context/WorkoutContext";
import { formatRelative } from "@/lib/format";
import {
  workoutDurationMinutes,
  workoutVolume,
} from "@/lib/progression";
import { FREE_HISTORY_DAYS, useSubscription } from "@/lib/subscription";
import type { Workout } from "@/lib/types";

const ONE_DAY_MS = 24 * 60 * 60 * 1000;

export default function HistoryScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { workouts, loaded, deleteWorkout } = useWorkout();
  const { isPro, ready: subReady, showUpgradePrompt } = useSubscription();

  const sorted = useMemo(
    () => [...workouts].sort((a, b) => b.startedAt - a.startedAt),
    [workouts],
  );

  // Until the subscription state is hydrated from storage, show the full
  // list. This prevents a Pro user from briefly seeing the "X workouts
  // hidden" banner / 14-day cap on app start.
  const visible = useMemo(() => {
    if (!subReady || isPro) return sorted;
    const cutoff = Date.now() - FREE_HISTORY_DAYS * ONE_DAY_MS;
    return sorted.filter((w) => w.startedAt >= cutoff);
  }, [sorted, isPro, subReady]);

  const hiddenCount = subReady && !isPro ? sorted.length - visible.length : 0;

  const isWeb = Platform.OS === "web";
  const topPad = isWeb ? Math.max(insets.top, 67) : insets.top;
  const bottomPad = isWeb ? 84 + 16 : 100;

  const Header = (
    <View style={styles.headerRow}>
      <View>
        <Text style={[styles.h1, { color: colors.foreground }]}>History</Text>
        <Text style={[styles.count, { color: colors.mutedForeground }]}>
          {visible.length} {visible.length === 1 ? "workout" : "workouts"}
          {!isPro && hiddenCount > 0
            ? "  \u00B7  last " + FREE_HISTORY_DAYS + " days"
            : ""}
        </Text>
      </View>
      <LiveDateTime variant="stack" align="right" />
    </View>
  );

  const FreeBanner = !isPro && hiddenCount > 0 ? (
    <Pressable
      onPress={showUpgradePrompt}
      style={({ pressed }) => [
        styles.banner,
        {
          backgroundColor: colors.card,
          borderColor: colors.primary,
          borderRadius: colors.radius,
          opacity: pressed ? 0.75 : 1,
        },
      ]}
    >
      <Feather name="lock" size={16} color={colors.primary} />
      <View style={{ flex: 1 }}>
        <Text style={[styles.bannerTitle, { color: colors.foreground }]}>
          {hiddenCount} earlier {hiddenCount === 1 ? "workout" : "workouts"}{" "}
          hidden
        </Text>
        <Text
          style={[styles.bannerSub, { color: colors.mutedForeground }]}
        >
          Free shows the last {FREE_HISTORY_DAYS} days. Upgrade for full
          history.
        </Text>
      </View>
      <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
    </Pressable>
  ) : null;

  if (loaded && visible.length === 0) {
    return (
      <View
        style={[
          styles.container,
          {
            backgroundColor: colors.background,
            paddingTop: topPad,
            paddingBottom: bottomPad,
          },
        ]}
      >
        <View style={[styles.headerRow, { paddingHorizontal: 20 }]}>
          <Text style={[styles.h1, { color: colors.foreground }]}>History</Text>
          <LiveDateTime variant="stack" align="right" />
        </View>
        {FreeBanner ? (
          <View style={{ paddingHorizontal: 20 }}>{FreeBanner}</View>
        ) : null}
        <EmptyState
          icon="clock"
          title={
            !isPro && hiddenCount > 0
              ? "No workouts in the last " + FREE_HISTORY_DAYS + " days"
              : "No workouts yet"
          }
          description={
            !isPro && hiddenCount > 0
              ? "Upgrade to Pro to see your full training history."
              : "Finish your first workout and it will show up here."
          }
        />
      </View>
    );
  }

  return (
    <FlatList
      style={[styles.container, { backgroundColor: colors.background }]}
      data={visible}
      keyExtractor={(w) => w.id}
      contentContainerStyle={{
        paddingTop: topPad + 8,
        paddingBottom: bottomPad,
        paddingHorizontal: 20,
      }}
      ListHeaderComponent={
        <View>
          {Header}
          {FreeBanner}
        </View>
      }
      ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
      renderItem={({ item }) => (
        <WorkoutRow workout={item} onDelete={deleteWorkout} />
      )}
      showsVerticalScrollIndicator={false}
    />
  );
}

function WorkoutRow({
  workout,
  onDelete,
}: {
  workout: Workout;
  onDelete: (id: string) => void;
}) {
  const colors = useColors();
  const volume = Math.round(workoutVolume(workout));
  const minutes = workoutDurationMinutes(workout);
  const totalSets = workout.exercises.reduce(
    (acc, e) => acc + e.sets.filter((s) => s.done).length,
    0,
  );

  const handleDelete = () => {
    Haptics.selectionAsync();
    Alert.alert(
      "Delete workout?",
      `${workout.category} ${"\u00B7"} ${formatRelative(workout.startedAt)}\nThis cannot be undone.`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            Haptics.notificationAsync(
              Haptics.NotificationFeedbackType.Warning,
            );
            onDelete(workout.id);
          },
        },
      ],
    );
  };

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: colors.radius,
        },
      ]}
    >
      <Pressable
        onPress={() => router.push(`/workout-detail/${workout.id}`)}
        style={({ pressed }) => [
          styles.cardTouchable,
          { opacity: pressed ? 0.85 : 1 },
        ]}
      >
        <View style={styles.cardTop}>
          <Text style={[styles.cardCategory, { color: colors.foreground }]}>
            {workout.category}
          </Text>
          <Text style={[styles.cardDate, { color: colors.mutedForeground }]}>
            {formatRelative(workout.startedAt)}
          </Text>
        </View>
        <View style={styles.metaRow}>
          <Meta icon="layers" value={`${workout.exercises.length} ex`} />
          <Meta icon="hash" value={`${totalSets} sets`} />
          <Meta icon="trending-up" value={`${volume.toLocaleString()} lb`} />
          {minutes > 0 ? <Meta icon="clock" value={`${minutes}m`} /> : null}
        </View>
      </Pressable>

      <Pressable
        onPress={handleDelete}
        hitSlop={10}
        style={({ pressed }) => [
          styles.deleteBtn,
          {
            backgroundColor: colors.destructive,
            opacity: pressed ? 0.7 : 1,
          },
        ]}
        accessibilityLabel="Delete workout"
        accessibilityRole="button"
      >
        <Feather name="trash-2" size={14} color={colors.primaryForeground} />
      </Pressable>
    </View>
  );
}

function Meta({
  icon,
  value,
}: {
  icon: React.ComponentProps<typeof Feather>["name"];
  value: string;
}) {
  const colors = useColors();
  return (
    <View style={styles.meta}>
      <Feather name={icon} size={12} color={colors.mutedForeground} />
      <Text style={[styles.metaText, { color: colors.mutedForeground }]}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerRow: {
    flexDirection: "row",
    alignItems: "baseline",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  h1: {
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    letterSpacing: -0.5,
  },
  count: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
  },
  banner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: 14,
  },
  bannerTitle: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  bannerSub: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 2,
  },
  card: {
    borderWidth: StyleSheet.hairlineWidth,
    position: "relative",
    overflow: "hidden",
  },
  cardTouchable: {
    padding: 16,
    paddingRight: 56,
  },
  cardTop: {
    flexDirection: "row",
    alignItems: "baseline",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  cardCategory: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  cardDate: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
  },
  metaRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 14,
  },
  meta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  metaText: {
    fontFamily: "Inter_500Medium",
    fontSize: 12,
  },
  deleteBtn: {
    position: "absolute",
    top: 10,
    right: 10,
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
});
